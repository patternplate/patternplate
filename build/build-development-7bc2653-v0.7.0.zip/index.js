/**!
 * Built: Mon Jun 15 2015 11:36:19 GMT+0200 (CEST)
 * Environment: development
 * Mode: server
 * Version: 0.7.0
 * Revision: 7bc2653
 * Branch: master
 * Tag: v0.5.1
 **/
require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){


},{}],"AtomsButton":[function(require,module,exports){
console.log('I am from the index!');

},{}],"MoleculesButtonRow":[function(require,module,exports){
var atomButton = require('atom-button');

console.log(atomButton);

},{"atom-button":"atom-button"}],"atom-button":[function(require,module,exports){
arguments[4]["AtomsButton"][0].apply(exports,arguments)
},{"dup":"AtomsButton"}]},{},[1])
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9wYXR0ZXJucGxhdGUtc2VydmVyL25vZGVfbW9kdWxlcy9icm93c2VyaWZ5L25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJfc3RyZWFtXzAuanMiLCJwYXR0ZXJucy9hdG9tcy9idXR0b24vX3N0cmVhbV8xLmpzIiwicGF0dGVybnMvbW9sZWN1bGVzL2J1dHRvbi1yb3cvX3N0cmVhbV8zLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTs7QUNEQTtBQUNBOztBQ0RBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3ZhciBmPW5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIik7dGhyb3cgZi5jb2RlPVwiTU9EVUxFX05PVF9GT1VORFwiLGZ9dmFyIGw9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGwuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sbCxsLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsIlxuIiwiY29uc29sZS5sb2coJ0kgYW0gZnJvbSB0aGUgaW5kZXghJyk7XG4iLCJ2YXIgYXRvbUJ1dHRvbiA9IHJlcXVpcmUoJ2F0b20tYnV0dG9uJyk7XG5cbmNvbnNvbGUubG9nKGF0b21CdXR0b24pO1xuIl19
